# Tomodachi Testcontainers

- [Tomodachi Testcontainers](#tomodachi-testcontainers)
  - [Installation](#installation)
  - [Quickstart and Examples](#quickstart-and-examples)
  - [Getting started](#getting-started)
    - [Testing standalone Tomodachi service](#testing-standalone-tomodachi-service)
    - [Changing Dockerfile location](#changing-dockerfile-location)
    - [Running Tomodachi container from pre-built image](#running-tomodachi-container-from-pre-built-image)
    - [Testing Tomodachi service with external dependencies](#testing-tomodachi-service-with-external-dependencies)
  - [Why end-to-end tests and Testcontainers?](#why-end-to-end-tests-and-testcontainers)
  - [Running Testcontainer tests in CI pipeline](#running-testcontainer-tests-in-ci-pipeline)
  - [Supported Testcontainers](#supported-testcontainers)
    - [Tomodachi](#tomodachi)
    - [Moto](#moto)
    - [LocalStack](#localstack)
    - [SFTP](#sftp)
  - [Additional resources and acknowledgements](#additional-resources-and-acknowledgements)
  - [Development](#development)

The library provides [testcontainers](src/tomodachi_testcontainers/containers/),
[pytest fixtures](src/tomodachi_testcontainers/pytest/),
and [test clients](src/tomodachi_testcontainers/clients/) for interacting with testcontainers.

It's built on top of [testcontainers-python](https://github.com/testcontainers/testcontainers-python) library.

[Testcontainers](https://testcontainers.com/) is an open-source framework for providing throwaway,
lightweight instances of databases, message brokers, web browsers,
or just about anything that can run in a Docker container.
It facilitates the use of Docker containers for functional, integration, and end-to-end testing.

## Installation

```bash
pip install tomodachi-testcontainers

# Extra dependency - SFTP container and asyncssh
pip install tomodachi-testcontainers[sftp]
```

## Quickstart and Examples

Tomodachi service examples are in [examples/](examples/) folder. Their end-to-end tests are in [tests/test_services](tests/test_services).

For full list of available testcontainers, check out [Supported Testcontainers](#supported-testcontainers) section,
[tomodachi_testcontainers.containers](src/tomodachi_testcontainers/containers/) module,
and the official [testcontainers-python](https://github.com/testcontainers/testcontainers-python) library -
it makes it easy to create your own testcontainers.

For full list of available pytest fixtures check out [tomodachi_testcontainers.pytest](src/tomodachi_testcontainers/pytest/) module,
and for test clients - [tomodachi_testcontainers.clients](src/tomodachi_testcontainers/clients/) module.

## Getting started

### Testing standalone Tomodachi service

Starting with a simple service that returns `HTTP 200` on the `/health` endpoint.

We'd like to test that the service is working.
To do that, we'll package the application as a Docker image, run the container,
send some requests, and assert the responses.

The example assumes that a Dockerfile for running the service is present in the
current working directory. An [example Dockerfile](examples/Dockerfile) is in the [examples/](examples/).

```python
import tomodachi
from aiohttp import web


class TomodachiServiceHealthcheck(tomodachi.Service):
    name = "service-healthcheck"

 @tomodachi.http("GET", r"/health")
 async def healthcheck(self, request: web.Request) -> web.Response:
 return web.json_response(data={"status": "ok"})
```

The following `tomodachi_container` fixture builds and runs the service as a Docker container.

```python
from typing import Generator, cast

import pytest
from docker.models.images import Image

from tomodachi_testcontainers.containers import TomodachiContainer
from tomodachi_testcontainers.utils import get_available_port


@pytest.fixture()
def tomodachi_container(tomodachi_image: Image) -> Generator[TomodachiContainer, None, None]:
    with TomodachiContainer(
        image=str(tomodachi_image.id),
        edge_port=get_available_port(),
    ) as container:
        yield cast(TomodachiContainer, container)
```

The `tomodachi_image` fixture is from the `tomodachi_testcontainers` library.
It builds a Docker image from a Dockerfile located in the current working directory.

The container is started by the `TomodachiContainer` context manager.
When the context manager finishes, the built Docker image and containers are removed.

The `tomodachi_image` fixture uses `tomodachi_testcontainers.containers.EphemeralDockerImage`.
It automatically deletes the Docker image after the container is stopped.

Furthermore, the `tomodachi_container` fixture will start a new Tomodachi service container
and remove the old one for every test.

In this example, `tomodachi_container` fixture is used to test that the `/health` endpoint
returns status code `HTTP 200` and a correct JSON response.

```python
import httpx
import pytest

from tomodachi_testcontainers.containers import TomodachiContainer


@pytest.mark.asyncio()
async def test_healthcheck_passes(tomodachi_container: TomodachiContainer) -> None:
    async with httpx.AsyncClient(base_url=tomodachi_container.get_external_url()) as client:
        response = await client.get("/health")

    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
```

`tomodachi_container.get_external_url` returns the container's URL that is accessible from the
host, e.g. `http://localhost:12345`. The port is selected randomly by `get_available_port` function
that has been used in `tomodachi_container` fixture.

For inter-container communication, use `tomodachi_container.get_internal_url` instead.

That's it! 🎉 We have tested that the Docker image can be built and run, and that the service
is working as expected, all with a Docker container, on the highest test level - end-to-end.

### Changing Dockerfile location

If the Dockerfile is not located in the current working directory, specify a new path
with the `TOMODACHI_TESTCONTAINER_DOCKERFILE_PATH` environment variable.

Examples:

- `TOMODACHI_TESTCONTAINER_DOCKERFILE_PATH=examples/` - specify just a directory, Dockerfile is inferred automatically
- `TOMODACHI_TESTCONTAINER_DOCKERFILE_PATH=examples/Dockerfile.testing` - explicitly specify the Dockerfile name

⚠️ Make sure that the environment variable is set before running `pytest` -
e.g. with [pytest-env](https://pypi.org/project/pytest-env/) plugin or
by setting it in the shell before running `pytest`.

### Running Tomodachi container from pre-built image

If the Tomodachi service Docker image is already built, you can run the container
by specifying the image ID in the `TOMODACHI_TESTCONTAINER_IMAGE_ID` environment variable.

It is useful when running tests in the CI pipeline when the image has been already built
on the build step.
Instead of building a new image from scratch for the tests, we want to test the exact same image that
will be pushed to a Container Registry and deployed to production.

Examples:

- `TOMODACHI_TESTCONTAINER_IMAGE_ID=sha256:56ca9586de1cf25081bb5f070b59b86625b6221bb26d7409a74e6051d7954c92`
- `TOMODACHI_TESTCONTAINER_IMAGE_ID=mycompany/my-tomodachi-application:1.0.0`

⚠️ Make sure that the environment variable is set before running `pytest`.

### Testing Tomodachi service with external dependencies

The main benefit of Testcontainers is that it allows testing an application with
production-like external dependencies - databases, message brokers, file stores, HTTP APIs, etc.

For example, let's test a Tomodachi service that uses AWS S3 to store files.
The `TomodachiServiceS3` has one endpoint `/file/<key>` that returns a content of a file stored in AWS S3.

```python
import os

import tomodachi
from aiobotocore.session import get_session
from aiohttp import web
from types_aiobotocore_s3 import S3Client


def get_s3_client() -> S3Client:
    return get_session().create_client(
        "s3",
        aws_access_key_id=os.environ.get("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.environ.get("AWS_SECRET_ACCESS_KEY"),
        endpoint_url=os.environ.get("AWS_S3_ENDPOINT_URL"),
    )


class TomodachiServiceS3(tomodachi.Service):
    name = "service-s3"

    async def _start_service(self) -> None:
        self.bucket = "test-bucket"
        async with get_s3_client() as client:
            await client.create_bucket(Bucket=self.bucket)

    @tomodachi.http("GET", r"/file/(?P<key>[^/]+?)/?")
    async def get_file(self, request: web.Request, key: str) -> web.Response:
        async with get_s3_client() as client:
            s3_object = await client.get_object(Bucket=self.bucket, Key=key)
            content = await s3_object["Body"].read()
            return web.json_response({"content": content.decode()})
```

There are a couple of ways to test the service.

- Mock the AWS S3 client with `unittest.mock`:

- The simplest way, but it doesn't test the actual AWS S3 integration.
- We can't be sure that all calls to the AWS client are correct, without typos
  or surprising configuration mismatches.
- Although unit tests are necessary, they won't give us the last bit of confidence that the service will work in production.
- That's why it's necessary to _supplement_ unit tests with integration and end-to-end tests.

- Use a real AWS S3 bucket:

- This is the most production-like way, but has some significant drawbacks in automated testing.
- It requires a separate AWS account dedicated only to automated tests.
- It's tricky to setup AWS credentials and permissions securely in the CI pipeline.
- Need to be careful to not mutate production infrastructure.
- Costs some money for using real AWS services.
- It's slow, because we're making real network calls to AWS.

- Use cloud environment mock library like [LocalStack](https://localstack.cloud/) or [Moto](https://docs.getmoto.org/en/latest/)

- Although it's not a real AWS, it's very close to simulating AWS services,
  so that it can be confidently used in cloud service integration tests.
- Battle-tested and used by many organizations with a wide community support.
- Easy to use on a local machine and in the CI pipeline, simply run it in a Docker container and remove it when finished.
- Works well with testcontainers! This is the approach we'll take in this example. 🐳

As in the previous example, first, we need to create Tomodachi testcontainer fixture
to build and run the service under test. It's done with a `tomodachi_container` fixture
in the example below.

```python
from typing import Generator, cast

import pytest
from docker.models.images import Image as DockerImage

from tomodachi_testcontainers.containers import LocalStackContainer, TomodachiContainer
from tomodachi_testcontainers.utils import get_available_port


@pytest.fixture()
def tomodachi_container(
    tomodachi_image: DockerImage,
    localstack_container: LocalStackContainer,
    _restart_localstack_container: None,
) -> Generator[TomodachiContainer, None, None]:
    with (
        TomodachiContainer(image=str(tomodachi_image.id), edge_port=get_available_port())
        .with_env("AWS_REGION", "eu-west-1")
        .with_env("AWS_ACCESS_KEY_ID", "testing")
        .with_env("AWS_SECRET_ACCESS_KEY", "testing")
        .with_env("AWS_S3_ENDPOINT_URL", localstack_container.get_internal_url())
        .with_command("tomodachi run app.py --production")
    ) as container:
        yield cast(TomodachiContainer, container)
```

This time, `tomodachi_container` fixture is more involved. It uses
`localstack_container` fixture, provided by `tomodachi_testcontainers` library.
The fixture starts a `LocalStackContainer`.

After the `LocalStackContainer` is started, we can use its `get_internal_url` method
to get the URL of the container that is accessible _inside_ the Docker network.
This time, we need the internal URL of the container, because the `TomodachiContainer`
needs to communicate with `LocalStackContainer`, and they both run in the same Docker network.

The LocalStack's `internal_url` is passed to `TomodachiContainer` as an environment variable `AWS_S3_ENDPOINT_URL`,
following [12-factor app principle of providing app configuration in environment variables](https://12factor.net/config).

The `tomodachi_container` fixture also uses the `_restart_localstack_container` fixture,
that restarts the `LocalStackContainer` after every test.
It resets the state of LocalStack after every test so that each new test starts
from a clean and predictable state. That way, we avoid flaky tests that depend on the
state of the previous test or their execution order.
As a downside, it takes a bit more time to restart the container after every test,
so it might not be necessary for every test.

That's the setup, now on to the application test. 🧪

```python
import httpx
import pytest
from types_aiobotocore_s3 import S3Client

from tomodachi_testcontainers.containers import TomodachiContainer


@pytest.mark.asyncio()
async def test_upload_and_read_file(
    tomodachi_container: TomodachiContainer,
    localstack_s3_client: S3Client,
) -> None:
    await localstack_s3_client.put_object(
        Bucket="test-bucket",
        Key="hello-world.txt",
        Body=b"Hello, World!",
    )

    async with httpx.AsyncClient(base_url=tomodachi_container.get_external_url()) as http_client:
        response = await http_client.get("/file/hello-world.txt")

    assert response.status_code == 200
    assert response.json() == {"content": "Hello, World!"}
```

In the test setup/arrangement step, the test uses `localstack_s3_client`
fixture to upload a file to the AWS S3 bucket. The `localstack_s3_client`
is yet another helper fixture provided by `tomodachi_testcontainers`.
It creates a new S3 client configured to communicate with the `LocalStackContainer`.

For full list of available fixtures, check out [tomodachi_testcontainers.pytest](src/tomodachi_testcontainers/pytest/) module.

In the act step, the test sends a request to the `/file/hello-world.txt` endpoint
to read the contents of a file, and in the assert step verifies that the response is correct.

⚠️ Note that to make the request to the running `TomodachiContainer`, the
HTTP client (httpx) uses `tomodachi_container.get_external_url` to get the URL
of the `TomodachiContainer` that is accessible from the host, because the
`pytest` runs on the host machine, and not inside the Docker network.

Awesome! 🚀 We have tested that our application is working with production-like
infrastructure, and established confidence that it will work
in the real environment as well.

For more examples, see [examples/](examples/) and tests in [tests/test_services](tests/test_services).

## Why end-to-end tests and Testcontainers?

TODO

https://www.cosmicpython.com/book/chapter_05_high_gear_low_gear.html#types_of_test_rules_of_thumb

- Symmetry

- _benefits of E2E tests_
- _note of caution about not overdoing end-to-end tests and minding the test pyramid_
- _links to cosmicpython book about test pyramid?_

- Testcontainers are meant to be run locally

## Running Testcontainer tests in CI pipeline

To run testcontainers in the CI pipeline, you'll need a container runtime installed
on the CI server (GitHub Actions, Jenkins etc.). That's pretty much it!
Running tests in the CI shouldn't much different from running them locally.

This libraries CI pipeline is running in GitHub Actions, and using the
`ubuntu-latest` image, which has Docker pre-installed, so no extra setup is needed.

Generally there're two approaches to running tests in CI pipeline:

1. Install programming language runtime and dependencies on the CI server,
   and run the tests directly on the CI server too. Discard CI server after
   pipeline has finished for the next run to start from a clean state.

   - That's very similar to how tests are run on the local machine.
   - This works really well with GitHub actions, and this approach is used in
     this library's CI pipeline.
   - See this library GitHub Actions pipeline example in
     [.github/workflows/python-package.yml](.github/workflows/python-package.yml).

2. Run tests from inside a Docker container.
   In this approach, the application code, its dependencies and tests
   are first packaged into a Docker image by the CI server, and the tests are run
   from inside the Docker container. It usually requires a multi-stage
   Dockerfile with two stages - first stage with all development dependencies
   installed (dev/test stage), and the second stage with only production dependencies
   and production code (production/release stage).
   (TODO move this to tomodachi-testcontainers-github-actions repo)

   - This approach isolates how the tests are run from the mechanics of
     the specific CI server you're using.
   - CI server only needs a container runtime installed.
   - CI server runs a Docker image from the dev/test stage, and runs
     the test command in the container.
   - However, since the application itself is tested as a (test)container,
     the container that's running the tests must be able to run new Docker containers itself.
   - This can be done with
     ["Docker-from-Docker"](https://code.visualstudio.com/remote/advancedcontainers/use-docker-kubernetes)
     method by mounting the Docker Unix socket from the host machine to the container.
   - ⚠️ In the end-to-end tests, we want to test the exact same Docker image that's
     going to be deployed to production, so the testcontianer tests must be ran
     against the production/release stage Docker image. Use environment variable
     `TOMODACHI_TESTCONTAINER_IMAGE_ID` to specify the image ID of the production/release stage.
   - Dev container -- launches/tests --> Release container

TODO Link to <https://github.com/filipsnastins/tomodachi-testcontainers-github-actions>

## Supported Testcontainers

| Container Name | Default Image               | Fixture                |                                                        Image Env Var Override |
| :------------- | :-------------------------- | :--------------------- | ----------------------------------------------------------------------------: |
| Tomodachi      | n/a (build from Dockerfile) | `tomodachi_image`      | `TOMODACHI_TESTCONTAINER_IMAGE_ID`, `TOMODACHI_TESTCONTAINER_DOCKERFILE_PATH` |
| Moto           | `motoserver/moto:latest`    | `moto_container`       |                                                 `MOTO_TESTCONTAINER_IMAGE_ID` |
| LocalStack     | `localstack/localstack:2.1` | `localstack_container` |                                           `LOCALSTACK_TESTCONTAINER_IMAGE_ID` |
| SFTP           | `atmoz/sftp:latest`         | `sftp_container`       |                                                 `SFTP_TESTCONTAINER_IMAGE_ID` |

### Tomodachi

Tomodachi - a lightweight microservices library on Python asyncio.

Repository: <https://github.com/kalaspuff/tomodachi>

### Moto

Moto is a library that allows your tests to mock out AWS Services.

Repository: <https://github.com/getmoto/moto>
Docker Hub: <https://hub.docker.com/r/motoserver/moto>

### LocalStack

LocalStack provides an easy-to-use test/mocking framework for developing cloud applications.

Repository: <https://github.com/localstack/localstack>
DockerHub: <https://hub.docker.com/r/localstack/localstack>

### SFTP

Easy to use SFTP (SSH File Transfer Protocol) server with OpenSSH.

Repository: <https://github.com/atmoz/sftp>
DockerHub: <https://hub.docker.com/r/atmoz/sftp>

- Available as an extra dependency `sftp` - install with
  `pip install tomodachi-testcontainers[sftp]` or `poetry install -E sftp`

## Additional resources and acknowledgements

- [testcontainers.com](https://testcontainers.com/) - home of testcontainers

- [testcontainers-python](https://testcontainers-python.readthedocs.io/) - Python SDK

- Talk ["Integration tests are needed and simple"](https://softwaregarden.dev/en/talks/integration-tests-are-needed-and-simple/)
  by [Piotr Przybyl](https://softwaregarden.dev/en/) - explains the why behind the need
  for integration testing and gives a demo on Testcontainers

- <https://www.cosmicpython.com>

- <https://martinfowler.com/bliki/TestPyramid.html>

- <https://testing.googleblog.com/2015/04/just-say-no-to-more-end-to-end-tests.html>

- <https://www.symphonious.net/2015/04/30/making-end-to-end-tests-work/>

## Development

- Install dev dependencies with [Poetry](https://python-poetry.org/)

```bash
poetry install --all-extras
poetry shell
pre-commit install
```

- Run tests

```bash
pytest
poetry run test-ci
```

- Format and lint code

```bash
poetry run format
poetry run lint
```

- Run all commit hooks at once

```bash
poetry run hooks
```

- Build package release

```bash
poetry build
```
